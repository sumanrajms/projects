#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>
#include<QString>
#include<QDebug>
using namespace std;

class Employee
{
public:
    Employee();
    ~Employee();
    int empid() const;
    void setEmpid(int newEmpid);

    const QString &empname() const;
    void setEmpname(const QString &newEmpname);

    int salary() const;
    void setSalary(int newSalary);

private:
    int m_empid;
    QString m_empname;
    int m_salary;
};

#endif // EMPLOYEE_H
