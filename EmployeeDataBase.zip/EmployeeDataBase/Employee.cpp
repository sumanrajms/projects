#include "Employee.h"

Employee::Employee()
{
qDebug()<<Q_FUNC_INFO<<Qt::endl;
}
Employee::~Employee()
{
qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

int Employee::empid() const
{
    return m_empid;
}

void Employee::setEmpid(int newEmpid)
{
    m_empid = newEmpid;
}

const QString &Employee::empname() const
{
    return m_empname;
}

void Employee::setEmpname(const QString &newEmpname)
{
    m_empname = newEmpname;
}

int Employee::salary() const
{
    return m_salary;
}

void Employee::setSalary(int newSalary)
{
    m_salary = newSalary;
}
