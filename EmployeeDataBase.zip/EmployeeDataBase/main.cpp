#include "Widget.h"
#include"Employee.h"
#include <QApplication>
#include<QList>
#include<QtSql/QSqlDatabase>
#include<QtSql/QSqlQuery>
QString storeEmployeeData( QList<Employee> el)
{
    qDebug()<<Q_FUNC_INFO<<"Data addedd sucessfully"<<Qt::endl;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/User/Desktop/DataBase/SampleDB.db");
    if(db.open()){
        qDebug()<<"DB Connected Successfully"<<Qt::endl;
        QSqlQuery qr;
        for(int i=0;i<el.size();i++){
            qr.prepare("insert into EmployeeData1(id,name,salary) values(?,?,?)");
            qr.bindValue(0,el.at(i).empid());
            qr.bindValue(1,el.at(i).empname());
            qr.bindValue(2,el.at(i).salary());
            if(qr.exec()){
                qDebug()<<"EmployeeData stored Successfully"<<Qt::endl;
            }
            else{
                qDebug()<<"can't execute Query"<<Qt::endl;
            }
        }
    }
    else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
    return "Employee data stored successfully";
}
QString readEmployeeData()
{

}
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QList<Employee> employeeList;
    Employee e1;
    e1.setEmpid(001);
    e1.setEmpname("bhargavi");
    e1.setSalary(20000);
    Employee e2;
    e2.setEmpid(002);
    e2.setEmpname("Darshan");
    e2.setSalary(20000);
    employeeList.append(e1);
    employeeList.append(e2);
    storeEmployeeData(employeeList);
    //    Widget w;
    //    w.show();
    return a.exec();
}
