#include "TourismPlace.h"

TourismPlace::TourismPlace(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

const QString &TourismPlace::image() const
{
    return m_image;
}

void TourismPlace::setImage(const QString &newImage)
{
    m_image = newImage;
}

const QString &TourismPlace::name() const
{
    return m_name;
}

void TourismPlace::setName(const QString &newName)
{
    m_name = newName;
}

const QString &TourismPlace::location() const
{
    return m_location;
}

void TourismPlace::setLocation(const QString &newLocation)
{
    m_location = newLocation;
}

const QString &TourismPlace::constrctdDate() const
{
    return m_constrctdDate;
}

void TourismPlace::setConstrctdDate(const QString &newConstrctdDate)
{
    m_constrctdDate = newConstrctdDate;
}

const QString &TourismPlace::state() const
{
    return m_state;
}

void TourismPlace::setState(const QString &newState)
{
    m_state = newState;
}
const QString &TourismPlace::district() const
{
    return m_district;
}
void TourismPlace::setDistrict(const QString &newDistrict)
{
    m_district = newDistrict;
}
const QString &TourismPlace::about() const
{
    return m_about;
}
void TourismPlace::setAbout(const QString &newAbout)
{
    m_about = newAbout;
}
