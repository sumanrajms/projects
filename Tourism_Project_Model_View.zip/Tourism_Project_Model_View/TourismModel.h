#ifndef TOURISMMODEL_H
#define TOURISMMODEL_H
#include<QDebug>
#include <QAbstractListModel>
#include <QObject>
#include<QList>
#include<DistrictModel.h>

class TourismModel : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit TourismModel(QObject *parent = nullptr);
    void init();
private:
    QList<DistrictModel*> m_Distlist;
    // QAbstractItemModel interface
public:
    int rowCount(const QModelIndex &parent) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;
    Q_INVOKABLE DistrictModel* getPlace(int index);
};

#endif // TOURISMMODEL_H
