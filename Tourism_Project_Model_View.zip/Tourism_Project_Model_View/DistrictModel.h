#ifndef DISTRICTMODEL_H
#define DISTRICTMODEL_H
#include<QDebug>
#include <QAbstractListModel>
#include <QObject>
#include<QList>
#include<QString>
#include"TourismPlace.h"

class DistrictModel : public QAbstractListModel
{
    Q_OBJECT

public:
    explicit DistrictModel(QObject *parent = nullptr);
    explicit DistrictModel(int a);
    void init(int a);

private:
    QString m_distName;
    QList<TourismPlace*> m_tourplacelistD;
    // QAbstractItemModel interface
public:
    int rowCount(const QModelIndex &parent) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;
    const QString &distName() const;
    void setDistName(const QString &newDistName);
};

#endif // DISTRICTMODEL_H
