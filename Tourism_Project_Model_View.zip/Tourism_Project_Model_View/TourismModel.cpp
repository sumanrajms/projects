#include "TourismModel.h"

TourismModel::TourismModel(QObject *parent)
    : QAbstractListModel{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    init();
}
void TourismModel::init()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    for(int i=0;i<5;i++){
    DistrictModel *dist=new DistrictModel(i);
    if( i==0)
    dist->setDistName("Davanagere");
    if(i==1)
    dist->setDistName("Bengaluru");
    if(i==2)
    dist->setDistName("Mysuru");
    if(i==3)
    dist->setDistName("Shivamogga");
    if(i==4)
    dist->setDistName("Uttara Kannada");
    if(i==5)
    dist->setDistName("Kodagu");
    m_Distlist.append(dist);
}
}

int TourismModel::rowCount(const QModelIndex &parent) const
{
    qDebug()<<Q_FUNC_INFO<<m_Distlist.size()<<Qt::endl;
    return m_Distlist.size();
}

QVariant TourismModel::data(const QModelIndex &index, int role) const
{
    int row=index.row();
    DistrictModel *dist=m_Distlist.at(row);
    if(role){
        return dist->distName();
    }
    return "str";
}

QHash<int, QByteArray> TourismModel::roleNames() const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QHash<int, QByteArray> roles;
    roles[1]="dname";
    return roles;
}

DistrictModel *TourismModel::getPlace(int index)
{
     qDebug()<<Q_FUNC_INFO<<Qt::endl;
     DistrictModel *d=m_Distlist.at(index);
     return d;
}
