#ifndef TOURISMPLACE_H
#define TOURISMPLACE_H

#include<QString>
#include <QObject>
#include<QDebug>

class TourismPlace : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString link READ about)
public:
    explicit TourismPlace(QObject *parent = nullptr);

    const QString &image() const;
    void setImage(const QString &newImage);

    const QString &name() const;
    void setName(const QString &newName);

    const QString &location() const;
    void setLocation(const QString &newLocation);

    const QString &constrctdDate() const;
    void setConstrctdDate(const QString &newConstrctdDate);

    const QString &state() const;
    void setState(const QString &newState);

    const QString &district() const;
    void setDistrict(const QString &newDistrict);

    const QString &about() const;
    void setAbout(const QString &newAbout);


signals:
private:
    QString m_image;
    QString m_name;
    QString m_location;
    QString m_constrctdDate;
    QString m_state;
    QString m_district;
    QString m_about;

};

#endif // TOURISMPLACE_H
