#include "DistrictModel.h"

DistrictModel::DistrictModel(QObject *parent)
    : QAbstractListModel{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}
DistrictModel::DistrictModel(int a)
{
    this->init(a);
}
void DistrictModel::init(int a)
{
    if(a==0){
        for(int i=0;i<3;i++){
            TourismPlace *tour=new TourismPlace;
            if(i==0)
            {
                tour->setName("Pushkarani");
                tour->setLocation("Santebennuru");
                tour->setConstrctdDate("16th Century");
                tour->setDistrict("Davanagere");
                tour->setState("Karnataka");
                tour->setImage("qrc:/Pushkarani.jpg");
                tour->setAbout("https://en.wikipedia.org/wiki/Santhebennur_Pushkarini");
            }
            if(i==1){
                tour->setName("ShantiSagaraLake");
                tour->setLocation("Channagiri");
                tour->setConstrctdDate("12th Century");
                tour->setDistrict("Davanagere");
                tour->setState("Karnataka");
                tour->setImage("qrc:/lake.jpg");
                tour->setAbout("https://en.wikipedia.org/wiki/Shanti_Sagara");
            }
            if(i==2)
            {
                tour->setName("HariHareshwara Temple");
                tour->setLocation("Harihara");
                tour->setConstrctdDate("12th Century");
                tour->setDistrict("Davanagere");
                tour->setState("Karnataka");
                tour->setImage("qrc:/temple.jpg");
                tour->setAbout("https://en.wikipedia.org/wiki/Harihareshwara_Temple");
            }
            m_tourplacelistD.append(tour);
        }
    }
    if(a==1){
        for(int j=0;j<5;j++){
            TourismPlace *tour1=new TourismPlace;
            if(j==0)
            {
                tour1->setName("Cubbun Park");
                tour1->setLocation("Cubbon Park Bengaluru");
                tour1->setConstrctdDate("1874");
                tour1->setDistrict("Bengaluru");
                tour1->setState("Karnataka");
                tour1->setImage("qrc:/cubbon.jpg");
                tour1->setAbout("https://en.wikipedia.org/wiki/Cubbon_Park");
            }
            if(j==1){
                tour1->setName("LalBagh");
                tour1->setLocation("LalBagh Bengaluru");
                tour1->setConstrctdDate("1870");
                tour1->setDistrict("Bengaluru");
                tour1->setState("Karnataka");
                tour1->setImage("qrc:/lalbagh.jpg");
                tour1->setAbout("https://en.wikipedia.org/wiki/Lal_Bagh");
            }
            if(j==2)
            {
                tour1->setName("Bangalore Palace");
                tour1->setLocation("Bangalore Palace");
                tour1->setConstrctdDate("1912");
                tour1->setDistrict("Bengaluru");
                tour1->setState("Karnataka");
                tour1->setImage("qrc:/BgPalace.jpg");
                tour1->setAbout("https://en.wikipedia.org/wiki/Bangalore_Palace");
            }
            if(j==3)
            {
                tour1->setName("Vidhana Soudha");
                tour1->setLocation("Vidhana Soudha");
                tour1->setConstrctdDate("1956");
                tour1->setDistrict("Bengaluru");
                tour1->setState("Karnataka");
                tour1->setImage("qrc:/vidhan.jpg");
                tour1->setAbout("https://en.wikipedia.org/wiki/Vidhana_Soudha");
            }
            if(j==4)
            {
                tour1->setName("Iskon Temple");
                tour1->setLocation("Iskon Temple");
                tour1->setConstrctdDate("1997");
                tour1->setDistrict("Bengaluru");
                tour1->setState("Karnataka");
                tour1->setImage("qrc:/iskon.jpg");
                tour1->setAbout("https://en.wikipedia.org/wiki/ISKCON_Temple,_Bangalore");
            }
            m_tourplacelistD.append(tour1);
        }
    }
    if(a==2)
    {
        for(int k=0;k<5;k++)
        {
            TourismPlace *tour2=new TourismPlace;
            if(k==0){
                tour2->setName("Amba Vilasa Palce");
                tour2->setLocation("Mysore Palace");
                tour2->setConstrctdDate("1912");
                tour2->setDistrict("Mysuru");
                tour2->setState("Karnataka");
                tour2->setImage("qrc:/mysore_palace.jpg");
                tour2->setAbout("https://en.wikipedia.org/wiki/Mysore_Palace");
            }
            if(k==1)
            {
                tour2->setName("JayaChamarajendra Zoo");
                tour2->setLocation("Mysore Zoo");
                tour2->setConstrctdDate("1892");
                tour2->setDistrict("Mysuru");
                tour2->setState("Karnataka");
                tour2->setImage("qrc:/zoo.jpg");
                tour2->setAbout("https://www.mysuruzoo.info/");
            }
            if(k==2){
                tour2->setName("Chamundeshwari Temple");
                tour2->setLocation("Chamundi Hills");
                tour2->setConstrctdDate("12th Century");
                tour2->setDistrict("Mysuru");
                tour2->setState("Karnataka");
                tour2->setImage("qrc:/Chamundi_temple.jpg");
                tour2->setAbout("https://en.wikipedia.org/wiki/Chamundeshwari_Temple");
            }
            if(k==3){
                tour2->setName("KrishnaRaja Sagara Dam");
                tour2->setLocation("KRS Dam");
                tour2->setConstrctdDate("1932");
                tour2->setDistrict("Mysuru");
                tour2->setState("Karnataka");
                tour2->setImage("qrc:/KRS.jpg");
                tour2->setAbout("https://en.wikipedia.org/wiki/Krishna_Raja_Sagara");
            }
            if(k==4){
                tour2->setName("Lalith Mahal Palace");
                tour2->setLocation("Lalith Mahal");
                tour2->setConstrctdDate("1921");
                tour2->setDistrict("Mysuru");
                tour2->setState("Karnataka");
                tour2->setImage("qrc:/LallthMahal.jpg");
                tour2->setAbout("https://en.wikipedia.org/wiki/Lalitha_Mahal");
            }
             m_tourplacelistD.append(tour2);
        }
    }
}
const QString &DistrictModel::distName() const
{
    return m_distName;
}
void DistrictModel::setDistName(const QString &newDistName)
{
    m_distName = newDistName;
}

int DistrictModel::rowCount(const QModelIndex &parent) const
{
    qDebug()<<Q_FUNC_INFO<<m_tourplacelistD.size()<<Qt::endl;
    return m_tourplacelistD.size();
}
QVariant DistrictModel::data(const QModelIndex &index, int role) const
{
    int row=index.row();
    TourismPlace *tour=m_tourplacelistD.at(row);
    qDebug()<<Q_FUNC_INFO<<"Row="<<row<<"Role="<<role<<Qt::endl;
    switch (role) {
    case 1:return tour->name();break;
    case 2:return tour->location();break;
    case 3:return tour->constrctdDate();break;
    case 4:return tour->district();break;
    case 5: return tour->state();break;
    case 6: return tour->image();break;
    case 7:return tour->about();break;
    }
    return "str";
}
QHash<int, QByteArray> DistrictModel::roleNames() const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QHash<int, QByteArray> roles;
    roles[1]="pname";
    roles[2]="location";
    roles[3]="cdate";
    roles[4]="districts";
    roles[5]="statek";
    roles[6]="img";
    roles[7]="weblink1";
    return roles;
}
