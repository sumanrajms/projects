#include "CityModel.h"

CityModel::CityModel(QObject *parent)
    : QAbstractListModel{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    init();
}

void CityModel::print()
{
        qDebug()<<Q_FUNC_INFO<<Qt::endl;
        for(auto it=m_cityList.begin();it!=m_cityList.end();it++)
        {
          qDebug()<<"City Name"<<(*it)->cityName()<<Qt::endl;
        }
}

int CityModel::rowCount(const QModelIndex &parent) const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    return m_cityList.size();
}

QVariant CityModel::data(const QModelIndex &index, int role) const
{
     qDebug()<<Q_FUNC_INFO<<Qt::endl;
     WeatherModel *wt=this->m_cityList.at(index.row());
     if(role==1)
     {
         return wt->cityName();
     }
     return "QVariant";
}

QHash<int, QByteArray> CityModel::roleNames() const
{
    QHash<int ,QByteArray> roles;
    roles[1]="cityName";
    return roles;
}

WeatherModel *CityModel::getWeather(int index)
{
WeatherModel *w= m_cityList.at(index);

}

void CityModel::init()
{

    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    for(int i=0;i<10;i++)
    {
       WeatherModel *wm=new WeatherModel;
        if(i==0)
        {
            wm->setCityName("Bengaluru");
        }
        if(i==1){
            wm->setCityName("Davanagere");
        }
        if(i==2){
            wm->setCityName("Mysuru");}
        if(i==3){
            wm->setCityName("Mangaluru");}
        if(i==4){
            wm->setCityName("Hubballi");}
        if(i==5){
            wm->setCityName("Shivamogge");}
        if(i==6){
            wm->setCityName("Chitradurga");}
        if(i==7){
            wm->setCityName("Karawara");}
        if(i==8){
            wm->setCityName("Bellary");}
        if(i==9){
            wm->setCityName("Belagavi");}
        m_cityList.append(wm);
    }
    this->print();
}
