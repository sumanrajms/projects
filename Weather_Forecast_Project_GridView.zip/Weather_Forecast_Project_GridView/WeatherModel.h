#ifndef WEATHERMODEL_H
#define WEATHERMODEL_H
#include<QDebug>
#include <QAbstractListModel>
#include <QObject>
#include"Weather.h"

class WeatherModel : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit WeatherModel(QObject *parent = nullptr);
    // QAbstractItemModel interface
    int rowCount(const QModelIndex &parent) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;
    void init();

    const QString &cityName() const;
    void setCityName(const QString &newCityName);
    Q_INVOKABLE Weather* getW(int index);

private:
    QString m_cityName;
    QList<Weather*> m_weatherList;
};

#endif // WEATHERMODEL_H
