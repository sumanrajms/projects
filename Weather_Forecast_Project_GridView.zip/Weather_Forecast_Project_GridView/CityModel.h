#ifndef CITYMODEL_H
#define CITYMODEL_H

#include <QAbstractListModel>
#include <QObject>
#include<QDebug>
#include<QString>
#include"City.h"
#include"WeatherModel.h"

class CityModel : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit CityModel(QObject *parent = nullptr);
    void print();


    // QAbstractItemModel interface
public:
    int rowCount(const QModelIndex &parent) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    // QAbstractItemModel interface

    QHash<int, QByteArray> roleNames() const override;
    Q_INVOKABLE WeatherModel* getWeather(int index);

private:
    void init();
    QList<WeatherModel*> m_cityList;
};

#endif // CITYMODEL_H
