#include "WeatherModel.h"

WeatherModel::WeatherModel(QObject *parent)
    : QAbstractListModel{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    this->init();
}
void WeatherModel::init()
{
    for(int i=1;i<=24;i++){
        Weather *wr = new Weather;
        QString time = i<=12 ? QString::number(i)+":00 AM":QString::number(i)+":00 PM";
        QString temp = i<5 ? "25C°" : i<10 ? "26C°" : i<15 ? "27C°" : i<20 ? "28C°" : "29C°";
        QString img = i<5 ? "qrc:/night.png" : i<10 ? "qrc:/cloudy.png" : i<15 ? "qrc:/sunny.png" : i<20 ? "qrc:/rainy.png" : "qrc:/cloudy.png";
        wr->setTime(time);
        wr->setTemp(temp);
        wr->setImage(img);
        this->m_weatherList.append(wr);
    }
}
int WeatherModel::rowCount(const QModelIndex &parent) const
{
   qDebug()<<Q_FUNC_INFO<<Qt::endl;
    return m_weatherList.size();
    // FIXME: Implement me!
}
QVariant WeatherModel::data(const QModelIndex &index, int role) const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    if (!index.isValid())
        return QVariant();
    Weather *w = m_weatherList.at(index.row());
    switch (role) {
    case 1: return w->time();break;
    case 2:return w->temp();break;
    case 3:return w->image();break;
    }
    // FIXME: Implement me!
    return "QVariant()";
}
Weather *WeatherModel::getW(int index)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    Weather *w = m_weatherList.at(index);
    return w;
}
QHash<int, QByteArray> WeatherModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[1] = "timerole";
    roles[2] = "temprole";
    roles[3] = "iconrole";
    return roles;
}
const QString &WeatherModel::cityName() const
{
    return m_cityName;
}

void WeatherModel::setCityName(const QString &newCityName)
{
    m_cityName = newCityName;
}
