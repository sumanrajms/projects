#ifndef CITY_H
#define CITY_H
#include<QDebug>
#include<QString>
#include <QObject>

class City : public QObject
{
    Q_OBJECT
public:
    explicit City(QObject *parent = nullptr);

    const QString &cityName() const;
    void setCityName(const QString &newCityName);

    const QString &time() const;
    void setTime(const QString &newTime);

    const QString &temp() const;
    void setTemp(const QString &newTemp);

signals:
private:
    QString m_cityName;
    QString m_time;
    QString m_temp;

};

#endif // CITY_H
