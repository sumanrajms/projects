#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<QQmlContext>
#include"CityModel.h"
#include"WeatherModel.h"

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("cModel",new CityModel);
    qmlRegisterUncreatableType<Weather>("comps",1,0,"Weather","You are not suppose to create objects at qml");
    qmlRegisterUncreatableType<WeatherModel>("comps",1,0,"WeatherModel","You are not suppose to create objects at qml");
    qmlRegisterUncreatableType<CityModel>("comps",1,0,"MyCity","You are not suppose to create objects at qml");
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
