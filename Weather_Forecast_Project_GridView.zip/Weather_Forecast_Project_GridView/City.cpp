#include "City.h"

City::City(QObject *parent)
    : QObject{parent}
{
qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

const QString &City::cityName() const
{
    return m_cityName;
}

void City::setCityName(const QString &newCityName)
{
    m_cityName = newCityName;
}

const QString &City::time() const
{
    return m_time;
}

void City::setTime(const QString &newTime)
{
    m_time = newTime;
}

const QString &City::temp() const
{
    return m_temp;
}

void City::setTemp(const QString &newTemp)
{
    m_temp = newTemp;
}
