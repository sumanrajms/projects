#ifndef WEATHER_H
#define WEATHER_H
#include<QDebug>
#include <QObject>
#include<QString>
class Weather : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString timer READ time  )
      Q_PROPERTY(QString temper READ temp  )
public:
    explicit Weather(QObject *parent = nullptr);

    const QString &time() const;
    void setTime(const QString &newTime);

    const QString &temp() const;
    void setTemp(const QString &newTemp);

    const QString &image() const;
    void setImage(const QString &newImage);

signals:
private:
    QString m_time;
    QString m_temp;
    QString m_image;
};

#endif // WEATHER_H
