#include "Weather.h"

Weather::Weather(QObject *parent)
    : QObject{parent}
{
qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

const QString &Weather::time() const
{
    return m_time;
}

void Weather::setTime(const QString &newTime)
{
    m_time = newTime;
}

const QString &Weather::temp() const
{
    return m_temp;
}

void Weather::setTemp(const QString &newTemp)
{
    m_temp = newTemp;
}

const QString &Weather::image() const
{
    return m_image;
}

void Weather::setImage(const QString &newImage)
{
    m_image = newImage;
}
